<?php

namespace Drupal\role_config\Services;

use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Service description.
 */
class RoleAdminServices {

  /**
   * The container.
   *
   * @var \Symfony\Component\DependencyInjection\ContainerInterface
   */
  protected $container;

  /**
   * Constructs a RoleEditorServices object.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container.
   */
  public function __construct(ContainerInterface $container) {
    $this->container = $container;
  }

  /**
   * Method description.
   */
  // public function doSomething($account2) {
    public function makeAdministrator($account2) {
    // @DCG place your code here.
    $addRole = $account2->addRole('administrator');
    $account2->save();
    return 'Works fine Administrator';
  }

}
