<?php

namespace Drupal\role_config\Services;

use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Service description.
 */
class RoleEditorServices {

  /**
   * The container.
   *
   * @var \Symfony\Component\DependencyInjection\ContainerInterface
   */
  protected $container;

  /**
   * Constructs a RoleEditorServices object.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container.
   */
  public function __construct(ContainerInterface $container) {
    $this->container = $container;
  }

  /**
   * Method description.
   */

  public function makeEditor($account2) {
    // @DCG place your code here.
    // $role_already = false;
    $getRoles = $account2 ->getRoles();
    // dump($getRoles);
    // dump(in_array('content_editor', $getRoles));//true or false
    if(in_array('content_editor', $getRoles)){
      // $role_already = true;
      \Drupal::messenger()->addMessage(t('You have already present Role as Content editor'),'status');
      return 'Works fine Editor';
    }
    else{
      $addRole = $account2->addRole('content_editor');
      $account2->save();
    
      $mailManager = \Drupal::service('plugin.manager.mail');
      // dump($mailManager);
  
      $module = 'role_config';
      $key = 'assign_editor'; //key which is usage in rele_config.module file
      $to = \Drupal::currentUser()->getEmail();
      $params['role'] = 'Content editor';
      /**
       * Add Message for Role assign
       */
      /* if($role_already){
       *  $params['message'] = "You have already present Role as Content editor";
       * }
       * else{
       *  $params['message'] = "Congratulation! You have assign Role to Content editor";
       * }
       **/

      $params['message'] = "Congratulation! You have assign Role to Content editor"/*. $addRole*/;
      $langcode= \Drupal::currentUser()->getPreferredLangcode();
      $send = true;
  
      $result = $mailManager->mail($module, $key, $to, $langcode, $params, NULL, $send);
      // dump($result);

      if($result['result'] !== true){
        \Drupal::messenger()->addMessage(t('There was problem in sending mail'),'error');
      }
      else{
        \Drupal::messenger()->addMessage(t('Mail send successfully'),'status');
      }

      return 'Works fine Editor';
    }
  
  }

}
