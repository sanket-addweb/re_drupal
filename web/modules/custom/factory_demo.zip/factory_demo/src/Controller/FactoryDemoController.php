<?php

namespace Drupal\factory_demo\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Returns responses for factory_demo routes.
 */
class FactoryDemoController extends ControllerBase {

  /**
   * Builds the response.
   */
  public function build() {

    $build['content'] = [
      '#type' => 'item',
      '#markup' => $this->t('It works!'),
    ];

    return $build;
  }

}
