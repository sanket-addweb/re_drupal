<?php
namespace Drupal\factory_demo\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
// use Drupal\learn_services\HelloWorldSalutation;
use Drupal\factory_demo\Services\AssignRole;

/**
 * Returns responses for factory_demo routes.
 */

class SetRoleByEmailController extends ControllerBase{
  // private $addRole;

  private $user;
  private $setRoleByMail;
  





  /**
   * Builds the response.
   */
  public function build() {
    $userId = \Drupal::currentUser()->id();
		$account = \Drupal\user\Entity\User::load($userId);
		$email2= $account->getInitialEmail();
    $txt = (\Drupal::service('factory_demo.example'))->RoleFactory($email2);
    $build['content'] = [
      '#type' => 'item',
      '#markup' => $this->t("It works! $txt"),
      '#cache' => [
        'max-age' => 0,//If you do not clear cache on this page then changes not reflected to admin/people
      ],
    ];

    return $build;
  }

}

?>