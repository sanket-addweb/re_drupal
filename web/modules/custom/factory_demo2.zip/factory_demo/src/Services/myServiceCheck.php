<?php
namespace Drupal\factory_demo\Services;

class myServiceCheck {
    public function demo32(){
        return "works great";
    }
}
