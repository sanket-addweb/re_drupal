<?php

namespace Drupal\factory_demo\Services;

use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Service description.
 */
class ExampleService {

  /**
   * The container.
   *
   * @var \Symfony\Component\DependencyInjection\ContainerInterface
   */
  protected $container;

  /**
   * Constructs an ExampleService object.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container.
   */
  public function __construct(ContainerInterface $container) {
    $this->container = $container;
  }

  /**
   * Method description. 
   */
  public function RoleFactory($email) {
    // public function doSomething(){
    // @DCG place your code here.
    $userId = \Drupal::currentUser()->id();
		$account = \Drupal\user\Entity\User::load($userId);
		// $email= $account->getInitialEmail();

		$reverse = strrev($email);
		$contents = explode('@', $reverse);
		$emailExt = strrev($contents[0]);
		if($emailExt=='addwebsolution.in'){
			//Administrator
			$addRole = $account->addRole('administrator');
      $account->save();
		} 
    elseif($emailExt == 'gmail.com'){
      //content_editor
      $addRole = $account->addRole('content_editor');
      $account->save();
    }
		else{
      $addRole = $account->addRole('moderator');
      $account->save();
		}
    return "works";
  }

}
