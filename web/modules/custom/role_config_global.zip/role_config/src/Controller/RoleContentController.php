<?php

namespace Drupal\role_config\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\role_config\ContentFactory;

/**
 * Returns responses for role_config routes.
 */
class RoleContentController extends ControllerBase {

  private $content;

  public function __construct(){
    // $this->content = new ContentFactory();
  }

  public function getContent(){
    $user = \Drupal::currentUser();
    // dump($user);

    $userId = $user->id();
    // dump($userId);

    $account2 = \Drupal\user\Entity\User::load($userId);
    // dump($account2);

    // $email = $user->getEmail();
    $email = $user->getEmail();
    // dump($email);
    // $account2->addRole('roleToAdd');
    // $newRole=$account2->getRoles();
    // dump($newRole);
    // $user->save();
    // exit;

    $pattern = "/[@\s:]/";
    $components = preg_split($pattern, $email);

    if($components[1]=='addwebsolution.in'){
			//Administrator
      // return new adminRole($account);
			$addRole = $account2->addRole('administrator');
      $account2->save();
		} 
    elseif($components[1] == 'gmail.com'){
      //content_editor 
      // return (\Drupal::service('role_config.editorRole'))->setEditorRole($account);
      // return (\Drupal::service('role_config.example'))->doSomething($account2);//works

      $txt = (\Drupal::service('role_config.example'))->makeEditor($account2);
      // $addRole = $account2->addRole('content_editor');
      // $account2->save();
    }
		else{
      // return new moderatorRole($account);
      $addRole = $account2->addRole('moderator');
      $account2->save();
		}

    return [
      '#markup' => "This is works and $txt",
      '#cache' => [
        'max-age' => 0,
      ],
    ];
  }
  /**
   * Builds the response.
   */
  public function build() {

    $build['content'] = [
      '#type' => 'item',
      '#markup' => $this->t("It works!"),
    ];

    return $build;
  }

}




